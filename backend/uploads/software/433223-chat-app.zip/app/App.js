import AppNavigator from './src/components/AppNavigator';

export default function App() {
  return (
    <>
      <AppNavigator />
    </>
  );
}
